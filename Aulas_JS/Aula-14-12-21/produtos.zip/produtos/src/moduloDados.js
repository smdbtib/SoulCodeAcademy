const produtos = [
  { id: 10, nome: "feijão", valor: 8.0, categoria: "alimentos" },
  { id: 11, nome: "arroz", valor: 9.0, categoria: "alimentos" },
  { id: 12, nome: "milho", valor: 3.5, categoria: "alimentos" },
  { id: 13, nome: "creme dental", valor: 2.85, categoria: "higiene" },
  { id: 14, nome: "sabonete", valor: 1.95, categoria: "higiene" },
  { id: 15, nome: "shampoo", valor: 21.0, categoria: "higiene" },
  { id: 16, nome: "condicionador", valor: 17.0, categoria: "higiene" },
  { id: 17, nome: "Asinha de Frango", valor: 12.9, categoria: "alimentos" },
  { id: 18, nome: "Picanha Suína", valor: 23.6, categoria: "alimentos" },
  { id: 19, nome: "Blusa Azul", valor: 39.6, categoria: "vestimenta" },
  { id: 20, nome: "Bermuda Jeans", valor: 59.4, categoria: "vestimenta" }
];
// Intância de transmissão na rota.
export default produtos;
